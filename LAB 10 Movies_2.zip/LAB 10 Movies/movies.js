var request = require('request')

// https://www.googleapis.com/books/v1/volumes?q=swift&maxResults=40&fields=items(id,volumeInfo(title,authors))

exports.search = function(query, callback) { //callback is an output parameter, kind of a return parameter (see #)
  console.log('inside movies.search(' + query + '....)')
  if (typeof query !== 'string' || query.length === 0) {
  	console.log('No word for query')
    callback({code:400, response:{status:'error', message:'No word for query'}})	//# create an object and return it via callback
  }


	//line 12-13: compose a request to an exteranl Web API
  const url = 'https://api.themoviedb.org/3/search/movie?api_key=101a1944787dd31b8f10b34f7b52140c&language=en-US&query=&page=1&include_adult=false'
  const google_query = {query:query,language:'en-US'}
  
  
  
  
  
  
  request.get({url: url, qs: google_query}, function(err, res, body) {	//function executed on receiving respond from Web API
    if (err) {
    	console.log('Movie Search failed')
      callback({code:500, response:{status:'error', message:'Search failed', data:err}})
    }

    const json = JSON.parse(body)	//convert body to object
    const results = json.results
    if (results){
	    const movies = results.map(function(element) {
	      
	        //{id:element.id, title:element.title}
	      
	     obj = {id:element.id, title:element.title,
	      description:element.overview,
	      rating:element.popularity }

	   //   if (typeof (element.imageLinks) == "undefined") obj.image = ''
	   //   else obj.image = element.imageLinks.small
	    	return obj;
	    })
	    console.log(movies.length +' movies found')
	    callback({code:200, response:{status:'success', message:movies.length+' movies found', data:movies}})
    }
    else
    	callback({code:200, response:{status:'success', message:'No movies found', data:''}})
  })
}


