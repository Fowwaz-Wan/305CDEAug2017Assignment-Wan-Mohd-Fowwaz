/*global angular  */

/* we 'inject' the ngRoute module into our app. This makes the routing functionality to be available to our app. */
var myApp = angular.module('myApp', ['ngRoute'])	//NB: ngRoute module for routing and deeplinking services and directives

/* the config function takes an array. */
myApp.config( ['$routeProvider', function($routeProvider) {
  $routeProvider
    .when('/search', {
		  templateUrl: 'templates/search.html',
      controller: 'searchController'
		})
    .when('/detail/:id', {
      templateUrl: 'templates/detail.html',
      controller: 'detailController'
    })
    .when('/favourites', {
		  templateUrl: 'templates/favourites.html',
      controller: 'favouritesController'
		})
    .otherwise({
		  redirectTo: 'search'
		})
	}])


myApp.controller('searchController', function($scope, $http) {
  $scope.message = 'This is the search screen'

  $scope.reqPost = function(req, res){
  	var url = 'https://fowwaz-fowwazwan.c9users.io/movies'
  	console.log('POST ' +url)
  	$http.post(url).success(function(response) {
      console.log(response)
  	})
  }

  $scope.search = function($event) {
    console.log('search()')
    if ($event.which == 13 || $event.which == 113) { // enter key presses
      var searchTerm = $scope.searchTerm
      var url = ''
      if ($event.which == 13)
      	url = 'https://api.themoviedb.org/3/search/movie?api_key=101a1944787dd31b8f10b34f7b52140c&language=en-US&query='+searchTerm
      else if($event.which == 113)
      	url = 'https://fowwaz-fowwazwan.c9users.io/movies?q='+searchTerm

      console.log(url)
      $http.get(url).success(function(resp) {
        console.log(resp)
        if (resp.data)
        	$scope.movies = resp.data
        else if (resp.results)
        	$scope.movies = resp.results
        //$scope.searchTerm = ''
      })
    }
  }
})

myApp.controller('detailController', function($scope, $routeParams, $http) {
  $scope.message = 'This is the detail screen'
  $scope.id = $routeParams.id

  var url = 'https://api.themoviedb.org/3/movie/'+$scope.id+'?api_key=101a1944787dd31b8f10b34f7b52140c&language=en-US'
  
  $http.get(url).success(function(rspBook) {
    console.log("found movie" + $scope.id)
    
   $scope.book = {}
    $scope.book.original_title = rspBook.original_title
    $scope.book.overview = rspBook.overview
    $scope.book.popularity = rspBook.popularity
    $scope.book.poster_path = 'https://image.tmdb.org/t/p/w500/'+rspBook.poster_path
  })

  $scope.addToFavourites = function(id, title) {
    console.log('adding: '+id+' to favourites.')
    localStorage.setItem(id, title)
  }
})

myApp.controller('favouritesController', function($scope) {
  console.log('fav controller')
  $scope.message = 'This is the favourites screen'
  var init = function() {
    console.log('getting movies')
    var results = new Array();		//alt: = []; for blank array obj
    //for (var key in localStorage) {	//for-in will include key, getItem, setItem, removeItem, clear & length
    for(var i = 0; i < localStorage.length; i++) {
    	var key = localStorage.key(i);	//native methods are ignored
    	var obj = {};
    	//items.push( {key: localStorage.getItem(key)} )  //TRY1 {key: ...} forced to hardcode key
    	//items.push(obj[key] = localStorage.getItem(key))	//TRY2 {dym-key: ...} hard to code in <ng-repeat>
    	results.push({id: key, title:localStorage.getItem(key)})  //TRY3 OK
      //alt: items[key] = localStorage[key]
    }
    console.log(results)
    $scope.movies = results
  }
  init()

  $scope.delete = function(id) {
  	localStorage.clear()
    console.log('deleting id '+id)
  }
  $scope.deleteAll = function(){ localStorage.clear(); init();}
})






